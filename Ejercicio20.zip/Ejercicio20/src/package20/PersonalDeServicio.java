package package20;

public class PersonalDeServicio extends Empleado {
    private String seccion;

    public PersonalDeServicio(String nombre, String apellidos, String id, String estadoCivil, int añoIncorporacion, String despacho, String seccion) {
        super(nombre, apellidos, id, estadoCivil, añoIncorporacion, despacho);
        this.seccion = seccion;
    }

    public void trasladarSeccion(String nuevaSeccion) {
        this.seccion = nuevaSeccion;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Sección: " + seccion);
    }
}
