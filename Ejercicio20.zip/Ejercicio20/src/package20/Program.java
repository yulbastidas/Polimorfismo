package package20;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.println("Introduce los datos del Profesor:");
        System.out.print("Nombre: ");
        String nombreProf = sc.nextLine();
        System.out.print("Apellidos: ");
        String apellidosProf = sc.nextLine();
        System.out.print("ID: ");
        String idProf = sc.nextLine();
        System.out.print("Estado Civil: ");
        String estadoCivilProf = sc.nextLine();
        System.out.print("Año de Incorporación: ");
        int añoIncorporacionProf = sc.nextInt(); sc.nextLine(); 
        System.out.print("Despacho: ");
        String despachoProf = sc.nextLine();
        System.out.print("Departamento: ");
        String departamentoProf = sc.nextLine();

        Profesor profesor = new Profesor(nombreProf, apellidosProf, idProf, estadoCivilProf, añoIncorporacionProf, despachoProf, departamentoProf);
        
        
        System.out.println("\nIntroduce los datos del Estudiante:");
        System.out.print("Nombre: ");
        String nombreEst = sc.nextLine();
        System.out.print("Apellidos: ");
        String apellidosEst = sc.nextLine();
        System.out.print("ID: ");
        String idEst = sc.nextLine();
        System.out.print("Estado Civil: ");
        String estadoCivilEst = sc.nextLine();
        System.out.print("Curso: ");
        String cursoEst = sc.nextLine();

        Estudiante estudiante = new Estudiante(nombreEst, apellidosEst, idEst, estadoCivilEst, cursoEst);

        
        System.out.println("\nIntroduce los datos del Personal de Servicio:");
        System.out.print("Nombre: ");
        String nombrePS = sc.nextLine();
        System.out.print("Apellidos: ");
        String apellidosPS = sc.nextLine();
        System.out.print("ID: ");
        String idPS = sc.nextLine();
        System.out.print("Estado Civil: ");
        String estadoCivilPS = sc.nextLine();
        System.out.print("Año de Incorporación: ");
        int añoIncorporacionPS = sc.nextInt(); sc.nextLine(); 
        System.out.print("Despacho: ");
        String despachoPS = sc.nextLine();
        System.out.print("Sección: ");
        String seccionPS = sc.nextLine();

        PersonalDeServicio personalDeServicio = new PersonalDeServicio(nombrePS, apellidosPS, idPS, estadoCivilPS, añoIncorporacionPS, despachoPS, seccionPS);

        
        System.out.println("\nDatos del Profesor:");
        profesor.imprimir();
        
        System.out.println("\nDatos del Estudiante:");
        estudiante.imprimir();
        
        System.out.println("\nDatos del Personal de Servicio:");
        personalDeServicio.imprimir();
        
        sc.close();
    }
}
