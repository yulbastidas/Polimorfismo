package package19;

import java.util.Scanner;

public class Empresa {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.println("Introduce los datos del Secretario:");
        System.out.print("Nombre: ");
        String nombreSec = sc.nextLine();
        System.out.print("Apellidos: ");
        String apellidosSec = sc.nextLine();
        System.out.print("DNI: ");
        String dniSec = sc.nextLine();
        System.out.print("Dirección: ");
        String direccionSec = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefonoSec = sc.nextLine();
        System.out.print("Salario: ");
        double salarioSec = sc.nextDouble(); sc.nextLine(); 
        System.out.print("Despacho: ");
        String despachoSec = sc.nextLine();
        System.out.print("Fax: ");
        String faxSec = sc.nextLine();

        Secretario secretario = new Secretario(nombreSec, apellidosSec, dniSec, direccionSec, telefonoSec, salarioSec, despachoSec, faxSec);

       
        System.out.println("\nIntroduce los datos del Jefe de Zona:");
        System.out.print("Nombre: ");
        String nombreJefe = sc.nextLine();
        System.out.print("Apellidos: ");
        String apellidosJefe = sc.nextLine();
        System.out.print("DNI: ");
        String dniJefe = sc.nextLine();
        System.out.print("Dirección: ");
        String direccionJefe = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefonoJefe = sc.nextLine();
        System.out.print("Salario: ");
        double salarioJefe = sc.nextDouble(); sc.nextLine(); 
        System.out.print("Despacho: ");
        String despachoJefe = sc.nextLine();

        JefeDeZona jefeDeZona = new JefeDeZona(nombreJefe, apellidosJefe, dniJefe, direccionJefe, telefonoJefe, salarioJefe, despachoJefe, secretario);

        
        System.out.println("\nIntroduce los datos del Vendedor:");
        System.out.print("Nombre: ");
        String nombreVen = sc.nextLine();
        System.out.print("Apellidos: ");
        String apellidosVen = sc.nextLine();
        System.out.print("DNI: ");
        String dniVen = sc.nextLine();
        System.out.print("Dirección: ");
        String direccionVen = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefonoVen = sc.nextLine();
        System.out.print("Salario: ");
        double salarioVen = sc.nextDouble(); sc.nextLine(); 
        System.out.print("Matrícula: ");
        String matriculaVen = sc.nextLine();
        System.out.print("Marca: ");
        String marcaVen = sc.nextLine();
        System.out.print("Modelo: ");
        String modeloVen = sc.nextLine();
        System.out.print("Móvil: ");
        String movilVen = sc.nextLine();
        System.out.print("Área de Venta: ");
        String areaVentaVen = sc.nextLine();
        System.out.print("Porcentaje de Comisiones: ");
        double porcentajeComisionesVen = sc.nextDouble();

        Vendedor vendedor = new Vendedor(nombreVen, apellidosVen, dniVen, direccionVen, telefonoVen, salarioVen, matriculaVen, marcaVen, modeloVen, movilVen, areaVentaVen, porcentajeComisionesVen);

        
        System.out.println("\nDatos del Secretario:");
        secretario.imprimir();
        
        System.out.println("\nDatos del Jefe de Zona:");
        jefeDeZona.imprimir();
        
        System.out.println("\nDatos del Vendedor:");
        vendedor.imprimir();
        
        
    }
}
