package package19;

import java.util.List;

public class JefeDeZona extends Empleado {
    private String despacho;
    private Secretario secretario;
    private List<Vendedor> listaVendedores;
    private String matricula;
    private String marca;
    private String modelo;
    
    public JefeDeZona(String nombre, String apellidos, String DNI, String direccion, String telefono, double salario, String despacho, Secretario secretario) {
        super(nombre, apellidos, DNI, direccion, telefono, salario);
        this.despacho = despacho;
        this.secretario = secretario;
    }
    
    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Despacho: " + despacho);
        System.out.println("Secretario: " + secretario);
    }
    
    public void cambiarSecretario(Secretario nuevoSecretario) {
        this.secretario = nuevoSecretario;
    }
    
    public void cambiarCoche(String matricula, String marca, String modelo) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
    }
    
    public void darAltaVendedor(Vendedor vendedor) {
        listaVendedores.add(vendedor);
    }
    
    public void darBajaVendedor(Vendedor vendedor) {
        listaVendedores.remove(vendedor);
    }
}

