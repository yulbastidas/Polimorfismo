package package19;

import java.util.ArrayList;
import java.util.List;

public class Vendedor extends Empleado {
    private String matricula;
    private String marca;
    private String modelo;
    private String movil;
    private String areaVenta;
    private List<String> listaClientes;
    private double porcentajeComisiones;

    public Vendedor(String nombre, String apellidos, String DNI, String direccion, String telefono, double salario,
                    String matricula, String marca, String modelo, String movil, String areaVenta, double porcentajeComisiones) {
        super(nombre, apellidos, DNI, direccion, telefono, salario);
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.movil = movil;
        this.areaVenta = areaVenta;
        this.porcentajeComisiones = porcentajeComisiones;
        this.listaClientes = new ArrayList<>();
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Matricula: " + matricula + ", Marca: " + marca + ", Modelo: " + modelo);
        System.out.println("Área de Venta: " + areaVenta + ", Porcentaje de Comisiones: " + porcentajeComisiones);
    }

    public void darAltaCliente(String cliente) {
        listaClientes.add(cliente);
    }

    public void darBajaCliente(String cliente) {
        listaClientes.remove(cliente);
    }

    public void cambiarCoche(String matricula, String marca, String modelo) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
    }
}
