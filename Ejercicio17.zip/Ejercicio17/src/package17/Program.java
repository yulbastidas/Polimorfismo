package package17;

import java.util.Scanner;

public class Program {
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

    
     Circulo circulo = new Circulo();
     System.out.print("Ingrese el radio del círculo: ");
     circulo.setValor1(scanner.nextInt());
     System.out.println("Área del círculo: " + circulo.getArea());
     System.out.println("Perímetro del círculo: " + circulo.getPerimetro());
     System.out.println();

     
     Cuadrado cuadrado = new Cuadrado();
     System.out.print("Ingrese el lado del cuadrado: ");
     cuadrado.setValor1(scanner.nextInt());
     System.out.println("Área del cuadrado: " + cuadrado.getArea());
     System.out.println("Perímetro del cuadrado: " + cuadrado.getPerimetro());
     System.out.println();

     
     Rectangulo rectangulo = new Rectangulo();
     System.out.print("Ingrese la base del rectángulo: ");
     rectangulo.setValor1(scanner.nextInt());
     System.out.print("Ingrese la altura del rectángulo: ");
     rectangulo.setValor2(scanner.nextInt());
     System.out.println("Área del rectángulo: " + rectangulo.getArea());
     System.out.println("Perímetro del rectángulo: " + rectangulo.getPerimetro());
     System.out.println();

     
     Triangulo triangulo = new Triangulo();
     System.out.print("Ingrese la base del triángulo: ");
     triangulo.setValor1(scanner.nextInt());
     System.out.print("Ingrese la altura del triángulo: ");
     triangulo.setValor2(scanner.nextInt());
     System.out.println("Área del triángulo: " + triangulo.getArea());
     System.out.println("Perímetro del triángulo (aproximado): " + triangulo.getPerimetro());

     scanner.close();
 }
}
