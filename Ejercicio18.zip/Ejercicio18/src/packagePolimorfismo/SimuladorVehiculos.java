package packagePolimorfismo;

import java.util.Scanner;

public class SimuladorVehiculos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        System.out.print("Ingrese la matrícula del coche: ");
        String matriculaCoche = scanner.nextLine();
        System.out.print("Ingrese el número de puertas del coche: ");
        int numPuertas = scanner.nextInt();
        Coche coche = new Coche(matriculaCoche, numPuertas);

        
        scanner.nextLine(); 
        System.out.print("Ingrese la matrícula del camión: ");
        String matriculaCamion = scanner.nextLine();
        Camion camion = new Camion(matriculaCamion);

        
        System.out.print("Ingrese el peso del remolque: ");
        int pesoRemolque = scanner.nextInt();
        Remolque remolque = new Remolque(pesoRemolque);
        camion.ponRemolque(remolque);

        
        System.out.print("Ingrese la cantidad de aceleración para el coche: ");
        int aceleracionCoche = scanner.nextInt();
        coche.acelerar(aceleracionCoche);
        
        System.out.print("Ingrese la cantidad de aceleración para el camión: ");
        int aceleracionCamion = scanner.nextInt();
        camion.acelerar(aceleracionCamion);

        
        System.out.println(coche);
        System.out.println(camion);

        scanner.close();
    }
}
